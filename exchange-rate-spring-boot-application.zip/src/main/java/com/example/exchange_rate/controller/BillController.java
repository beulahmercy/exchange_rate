package com.example.exchange_rate.controller;

import com.example.exchange_rate.model.Bill;
import com.example.exchange_rate.model.User;
import com.example.exchange_rate.service.BillService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class BillController {

    private final BillService billService;

    public BillController(BillService billService) {
        this.billService = billService;
    }

    @PostMapping("/calculate")
    public double calculatePayableAmount(@RequestBody Bill bill, @RequestParam String targetCurrency) {
        User user = bill.getUser();
        return billService.calculatePayableAmount(bill, targetCurrency, user);
    }
}
