package com.example.exchange_rate.model;

public class User {
    private String type;
    private int tenureInYears;

    // Getters and Setters

    public int getTenureInYears() {
        return tenureInYears;
    }

    public String getType() {
        return type;
    }

    public void setTenureInYears(int tenureInYears) {
        this.tenureInYears = tenureInYears;
    }

    public void setType(String type) {
        this.type = type;
    }
}

