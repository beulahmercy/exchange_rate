package com.example.exchange_rate.service;

import com.example.exchange_rate.model.Bill;
import com.example.exchange_rate.model.User;
import org.springframework.stereotype.Service;

@Service
public class BillService {

    private final CurrencyService currencyService;
    private final DiscountService discountService;

    public BillService(CurrencyService currencyService, DiscountService discountService) {
        this.currencyService = currencyService;
        this.discountService = discountService;
    }

    public double calculatePayableAmount(Bill bill, String targetCurrency, User user) {
        double discount = discountService.calculateDiscount(bill, user);
        double amountAfterDiscount = bill.getTotalAmount() - discount;

        double exchangeRate = currencyService.getExchangeRate(bill.getCurrency(), targetCurrency);
        return amountAfterDiscount * exchangeRate;
    }
}
