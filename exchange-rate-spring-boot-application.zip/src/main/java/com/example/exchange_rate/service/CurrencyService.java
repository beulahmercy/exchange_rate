package com.example.exchange_rate.service;

import com.example.exchange_rate.config.CurrencyClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class CurrencyService {

    private final CurrencyClient currencyClient;

    @Value("${currency.api.key}")
    private String apiKey;

    public CurrencyService(CurrencyClient currencyClient) {
        this.currencyClient = currencyClient;
    }

    @Cacheable("exchangeRates")
    public double getExchangeRate(String fromCurrency, String toCurrency) {
        Map<String, Object> response = currencyClient.getExchangeRates(fromCurrency, apiKey);
        Map<String, Double> rates = (Map<String, Double>) response.get("conversion_rates");
        return rates.get(toCurrency);
    }
}
