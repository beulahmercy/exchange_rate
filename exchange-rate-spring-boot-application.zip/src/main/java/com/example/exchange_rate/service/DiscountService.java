package com.example.exchange_rate.service;

import com.example.exchange_rate.model.Bill;
import com.example.exchange_rate.model.User;
import org.springframework.stereotype.Service;

@Service
public class DiscountService {

    public double calculateDiscount(Bill bill, User user) {
        double total = bill.getTotalAmount();
        double discount = 0;

        // Percentage-based discounts
        if ("employee".equalsIgnoreCase(user.getType())) {
            discount = total * 0.30;
        } else if ("affiliate".equalsIgnoreCase(user.getType())) {
            discount = total * 0.10;
        } else if (user.getTenureInYears() > 2) {
            discount = total * 0.05;
        }

        // Per $100 discount
        discount += (int) (total / 100) * 5;

        // Exclude percentage-based discounts for groceries
        if ("groceries".equalsIgnoreCase(bill.getCategory())) {
            discount = Math.min(discount, total * 0.05);
        }

        return discount;
    }
}
