package com.example.exchange_rate;

import com.example.exchange_rate.service.DiscountService;
import com.example.exchange_rate.model.Bill;
import com.example.exchange_rate.model.User;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class DiscountServiceTest {

    private final DiscountService discountService = new DiscountService();

    @Test
    void testCalculateDiscountForEmployee() {
        User user = new User();
        user.setType("employee");
        Bill bill = new Bill();
        bill.setTotalAmount(200);
        bill.setCategory("electronics");

        double discount = discountService.calculateDiscount(bill, user);
        assertEquals(70, discount);
    }
}
